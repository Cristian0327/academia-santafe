module.exports=[50932,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_categorias_page_actions_39cc55b3.js.map