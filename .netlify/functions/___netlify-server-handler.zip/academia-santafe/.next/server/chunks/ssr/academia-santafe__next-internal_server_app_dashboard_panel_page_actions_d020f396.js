module.exports=[98951,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_dashboard_panel_page_actions_d020f396.js.map