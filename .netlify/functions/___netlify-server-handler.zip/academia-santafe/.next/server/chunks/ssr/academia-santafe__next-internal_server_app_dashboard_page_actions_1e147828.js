module.exports=[28195,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_dashboard_page_actions_1e147828.js.map