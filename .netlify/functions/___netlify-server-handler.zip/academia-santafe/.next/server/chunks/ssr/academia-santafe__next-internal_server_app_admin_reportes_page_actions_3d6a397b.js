module.exports=[69162,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_admin_reportes_page_actions_3d6a397b.js.map