module.exports=[81321,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_page_actions_8ef31688.js.map