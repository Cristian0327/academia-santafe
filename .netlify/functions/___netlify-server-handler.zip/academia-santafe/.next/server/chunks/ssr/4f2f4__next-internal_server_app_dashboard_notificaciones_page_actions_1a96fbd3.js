module.exports=[33365,(a,b,c)=>{}];

//# sourceMappingURL=4f2f4__next-internal_server_app_dashboard_notificaciones_page_actions_1a96fbd3.js.map