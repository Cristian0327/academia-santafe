module.exports=[50379,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_auth_error_page_actions_bab18240.js.map