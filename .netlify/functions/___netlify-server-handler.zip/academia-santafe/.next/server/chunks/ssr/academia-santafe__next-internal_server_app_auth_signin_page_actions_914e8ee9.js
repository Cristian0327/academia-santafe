module.exports=[65135,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_auth_signin_page_actions_914e8ee9.js.map