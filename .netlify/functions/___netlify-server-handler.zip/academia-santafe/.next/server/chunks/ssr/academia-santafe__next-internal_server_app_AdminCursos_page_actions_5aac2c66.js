module.exports=[67744,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_AdminCursos_page_actions_5aac2c66.js.map