module.exports=[45673,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_perfil_page_actions_f554a584.js.map