module.exports=[24639,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_cursos_page_actions_efa24b70.js.map