module.exports=[30971,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_admin_page_actions_3c859582.js.map