module.exports=[85358,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_curso_%5Bid%5D_page_actions_bed06ba6.js.map