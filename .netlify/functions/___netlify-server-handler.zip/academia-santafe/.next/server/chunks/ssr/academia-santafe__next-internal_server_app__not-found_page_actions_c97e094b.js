module.exports=[2550,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app__not-found_page_actions_c97e094b.js.map