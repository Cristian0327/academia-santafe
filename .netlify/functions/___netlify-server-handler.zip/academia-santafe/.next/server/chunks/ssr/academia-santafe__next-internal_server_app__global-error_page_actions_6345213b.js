module.exports=[30306,(a,b,c)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app__global-error_page_actions_6345213b.js.map