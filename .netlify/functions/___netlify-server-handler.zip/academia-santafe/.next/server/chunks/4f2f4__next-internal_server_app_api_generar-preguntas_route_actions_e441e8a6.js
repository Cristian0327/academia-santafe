module.exports=[81992,(e,o,d)=>{}];

//# sourceMappingURL=4f2f4__next-internal_server_app_api_generar-preguntas_route_actions_e441e8a6.js.map