module.exports=[49289,(e,o,d)=>{}];

//# sourceMappingURL=4f2f4__next-internal_server_app_api_user-profile_route_actions_4abab3cc.js.map