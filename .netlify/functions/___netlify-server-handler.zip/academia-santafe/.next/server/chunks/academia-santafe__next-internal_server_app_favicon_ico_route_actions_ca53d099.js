module.exports=[75683,(e,o,d)=>{}];

//# sourceMappingURL=academia-santafe__next-internal_server_app_favicon_ico_route_actions_ca53d099.js.map