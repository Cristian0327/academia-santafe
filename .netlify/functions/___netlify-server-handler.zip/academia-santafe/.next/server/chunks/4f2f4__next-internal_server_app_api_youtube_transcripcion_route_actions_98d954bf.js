module.exports=[97465,(e,o,d)=>{}];

//# sourceMappingURL=4f2f4__next-internal_server_app_api_youtube_transcripcion_route_actions_98d954bf.js.map