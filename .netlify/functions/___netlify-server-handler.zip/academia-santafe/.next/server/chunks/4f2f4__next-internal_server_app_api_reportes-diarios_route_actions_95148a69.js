module.exports=[51667,(e,o,d)=>{}];

//# sourceMappingURL=4f2f4__next-internal_server_app_api_reportes-diarios_route_actions_95148a69.js.map