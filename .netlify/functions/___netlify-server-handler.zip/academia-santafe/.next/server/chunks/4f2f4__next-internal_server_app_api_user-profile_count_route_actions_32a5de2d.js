module.exports=[30416,(e,o,d)=>{}];

//# sourceMappingURL=4f2f4__next-internal_server_app_api_user-profile_count_route_actions_32a5de2d.js.map