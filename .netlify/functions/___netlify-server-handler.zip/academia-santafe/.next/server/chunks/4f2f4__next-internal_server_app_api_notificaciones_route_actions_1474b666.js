module.exports=[71302,(e,o,d)=>{}];

//# sourceMappingURL=4f2f4__next-internal_server_app_api_notificaciones_route_actions_1474b666.js.map