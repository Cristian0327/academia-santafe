var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__b89b5a39._.js")
R.c("server/chunks/0d098_next_dist_esm_build_templates_app-route_1ab2b8bb.js")
R.c("server/chunks/[root-of-the-server]__7ba13571._.js")
R.c("server/chunks/0d098_next_0da482fe._.js")
R.c("server/chunks/academia-santafe__next-internal_server_app_favicon_ico_route_actions_ca53d099.js")
R.m(57334)
module.exports=R.m(57334).exports
