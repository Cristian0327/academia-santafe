var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notificaciones/route.js")
R.c("server/chunks/[root-of-the-server]__790fdacd._.js")
R.c("server/chunks/[root-of-the-server]__7ba13571._.js")
R.c("server/chunks/0d098_next_0da482fe._.js")
R.c("server/chunks/4f2f4__next-internal_server_app_api_notificaciones_route_actions_1474b666.js")
R.m(79481)
module.exports=R.m(79481).exports
