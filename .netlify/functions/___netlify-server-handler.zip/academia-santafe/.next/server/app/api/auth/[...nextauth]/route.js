var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__e24c575c._.js")
R.c("server/chunks/[root-of-the-server]__b52b4f3a._.js")
R.c("server/chunks/[root-of-the-server]__7ba13571._.js")
R.c("server/chunks/4f2f4__next-internal_server_app_api_auth_[___nextauth]_route_actions_d7080713.js")
R.m(19998)
module.exports=R.m(19998).exports
