var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reportes-diarios/route.js")
R.c("server/chunks/[root-of-the-server]__2cc32166._.js")
R.c("server/chunks/0d098_next_0da482fe._.js")
R.c("server/chunks/[root-of-the-server]__836219d1._.js")
R.c("server/chunks/[root-of-the-server]__7ba13571._.js")
R.c("server/chunks/4f2f4__next-internal_server_app_api_reportes-diarios_route_actions_95148a69.js")
R.m(93072)
module.exports=R.m(93072).exports
