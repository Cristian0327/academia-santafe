var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/youtube/transcripcion/route.js")
R.c("server/chunks/[root-of-the-server]__d2f0648b._.js")
R.c("server/chunks/[root-of-the-server]__7ba13571._.js")
R.c("server/chunks/0d098_next_0da482fe._.js")
R.c("server/chunks/4f2f4__next-internal_server_app_api_youtube_transcripcion_route_actions_98d954bf.js")
R.m(99212)
module.exports=R.m(99212).exports
