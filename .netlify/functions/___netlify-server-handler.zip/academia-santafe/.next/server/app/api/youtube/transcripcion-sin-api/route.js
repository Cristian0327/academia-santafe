var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/youtube/transcripcion-sin-api/route.js")
R.c("server/chunks/[root-of-the-server]__c52c477f._.js")
R.c("server/chunks/[root-of-the-server]__7ba13571._.js")
R.c("server/chunks/0d098_next_0da482fe._.js")
R.c("server/chunks/918f7_server_app_api_youtube_transcripcion-sin-api_route_actions_1d47e891.js")
R.m(45159)
module.exports=R.m(45159).exports
