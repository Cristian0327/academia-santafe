var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user-profile/count/route.js")
R.c("server/chunks/[root-of-the-server]__adc0bfe9._.js")
R.c("server/chunks/[root-of-the-server]__7ba13571._.js")
R.c("server/chunks/0d098_next_0da482fe._.js")
R.c("server/chunks/4f2f4__next-internal_server_app_api_user-profile_count_route_actions_32a5de2d.js")
R.m(40277)
module.exports=R.m(40277).exports
