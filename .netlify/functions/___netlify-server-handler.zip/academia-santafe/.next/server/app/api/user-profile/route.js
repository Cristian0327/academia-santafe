var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user-profile/route.js")
R.c("server/chunks/[root-of-the-server]__04553a3c._.js")
R.c("server/chunks/0d098_next_0da482fe._.js")
R.c("server/chunks/[root-of-the-server]__b52b4f3a._.js")
R.c("server/chunks/[root-of-the-server]__7ba13571._.js")
R.c("server/chunks/4f2f4__next-internal_server_app_api_user-profile_route_actions_4abab3cc.js")
R.m(46976)
module.exports=R.m(46976).exports
